**jquery-confirm version:**
v3.x.x

**I'm submitting a ...**  (check one with "x")
[ ] bug report
[ ] feature request
[ ] support request

**Current behavior:**
<!-- Describe how the bug manifests. -->

**Expected behavior:**
<!-- Describe what the behavior would be without the bug. -->

**Steps to reproduce:**

**Related code:**
```
insert any relevant code here
```

**Other information:**
